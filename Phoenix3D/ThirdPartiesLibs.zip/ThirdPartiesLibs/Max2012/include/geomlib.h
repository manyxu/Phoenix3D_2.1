#pragma once

#define IMPORTING
#include "geom.h"
#undef IMPORTING

